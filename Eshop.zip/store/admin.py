from django.contrib import admin
from store.models import Category,Product,Customer,Order

# Register your models here.





class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name']

admin.site.register([Category,Product,Customer,Order])



class ProductAdmin(admin.ModelAdmin):
    list_display = ['name','price','category']

class CustomerAdmin(admin.ModelAdmin):
    list_display = ['firstname','lastname','phone','email','password']

